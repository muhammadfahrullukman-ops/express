
# Patch Keamanan Express.js

## 🔧 Deskripsi Patch
Patch ini menonaktifkan header `X-Powered-By` pada aplikasi Express.js untuk mencegah pengungkapan informasi teknologi stack kepada pihak luar. Ini merupakan langkah kecil namun penting dalam meningkatkan keamanan aplikasi.

## ✅ Perubahan Kode
Tambahan baris ini dalam file utama aplikasi:
```js
app.disable('x-powered-by');
```

## 📁 File
- `example-app.js` → Aplikasi demo dengan patch keamanan.

## 🚀 Cara Upload ke GitHub
1. Fork repo: https://github.com/expressjs/express
2. Upload file ini ke repo hasil fork kamu.
3. Buat Pull Request (PR) ke repo utama.
4. Judul PR: `Security patch: Disable X-Powered-By header in Express`
5. Deskripsi PR:
    ```
    This patch disables the 'X-Powered-By' HTTP header, which is enabled by default in Express.js.

    Reason:
    - This header exposes internal framework info (`Express`) to the outside world.
    - Disabling it helps prevent fingerprinting and reduces potential attack surface.

    Patch includes:
    - A call to `app.disable('x-powered-by')` added to main app setup.

    This is a small but impactful security improvement.
    ```

## 🎁 Daftar Patch ke Google Patch Rewards
- Kunjungi: https://opensource.google.com/rewards/patch/
- Kirim tautan PR yang sudah kamu buat
